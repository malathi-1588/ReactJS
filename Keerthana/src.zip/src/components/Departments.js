import React from "react";
import Department_ss from "../assets/Department_ss.png"

const Departments = () =>
{
    return(
        <div>
            {/* <h2><b>Departments</b></h2> */}
            <img src={Department_ss}/>
        </div>
    ); 

}


export default Departments;