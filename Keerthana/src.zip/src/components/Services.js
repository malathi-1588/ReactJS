import React from "react"
import Services_ss from "../assets/Services_ss.png"

const Services = () =>
{
    return (
        <div>
            {/* <h2>Services</h2>  */}
            <img src={Services_ss}/>
        </div>

    );

}
export default Services;