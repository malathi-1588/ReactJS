import React from 'react';
import Sign_In_ss from "../assets/Sign_In_ss.png"
function SignIn()
{
    return (
        <div>
            <img src={Sign_In_ss}/>
        </div>
    );
}
export default SignIn