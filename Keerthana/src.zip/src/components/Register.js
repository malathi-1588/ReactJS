import React from 'react';
import Register_ss from '../assets/Register_ss.png'

function Register()
{
    return (
        <div>
             <img src={Register_ss}/>
        </div>
       
    );
}
export default Register