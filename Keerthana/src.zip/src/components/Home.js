import React from 'react';
import Home_ss from '../assets/Home_ss.png'
const Home = () => {
  return (
    <div>
      <h1>Welcome to Our <b>WALMART CLONE</b></h1>
      <img src={Home_ss}/>
      {/* You can add more content here */}
    </div>
  );
};

export default Home;
