// import Navbar from './components/Navbar'
import {BrowserRouter as Router, Routes,Route} from 'react-router-dom'
import Departments from './components/Departments';
import Services from './components/Services';
import Register from './components/Register';
import SignIn from './components/SignIn';
import Home from './components/Home'; // Adjust the import path if needed

function App() {
  return (
 <Routes>
  <Route path='/' element={<Home />} />
    <Route path='/Departments' element={<Departments/>}/>
    <Route path='/Services' element={<Services/>}/>
    <Route path='/Register' element={<Register/>}/>
    <Route path='/SignIn' element={<SignIn/>}/>
 </Routes>
  );
}
export default App;
// Bonus Questions
// Identify if the company you select has any AI and DS roles. 
//Ans: Walmart has been actively utilizing AI and data science across various aspects of their operations
// Study what they do. 
//Ans:Supply Chain Optimization,Customer Personalization,Price Optimization,Fraud Detection,
// Study their requirements. 
//Data Scientists,Machine Learning Engineers,AI Researchers,Data Analysts,Business Analysts,AI Product Managers,Data Engineers,AI ,Ethics and Compliance Specialists
// What do you think is the future of this company (in terms of growth)?
// Will AI and DS disrupt the sector 
//Ans:It's important to note that while AI and Data Science offer significant opportunities for improving efficiency and customer experiences, their successful implementation also requires careful consideration of data privacy, ethical concerns, and potential impacts on the workforce. 
// Will they successfully utilize AI and DS to cause disruption?
// Ans:Disruption is not guaranteed, as success depends on various internal and external factors. However, Walmart's significant resources, customer base, and existing infrastructure provide a strong foundation for leveraging AI and DS to bring about positive changes in the retail sector. For the most up-to-date information, it's recommended to follow Walmart's official communications and news releases regarding their AI and DS initiatives.
// See if you would be interested in making a career at this company/sector.
//Anything that gives me knowledge I'm ready to take it up

